/* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package gossipassign;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;


import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.util.Random;
import java.util.Scanner;

import com.google.protobuf.InvalidProtocolBufferException;


class Server1 {

    public interface Server extends Remote {

        public void hearGossip(byte b[]) throws RemoteException;
    }

    public static class ServerImpl extends UnicastRemoteObject
            implements Server {

        Registry rmiRegistry;
        static int id;
        static int hash[];
        public ServerImpl() throws RemoteException {    
            super();
        }

        public void start() throws Exception {
           //rmiRegistry = LocateRegistry.createRegistry(1410);
           hash=new int[GossipAssign.n+1];
           for(int i=0;i<=GossipAssign.n;i++)
           {
        	   hash[i]=-1;
        	   
           }
           hash[GossipAssign.idy]=-1;
            Naming.rebind("server"+id, this);
            
            System.out.println("Server started "+id );
        }

        public void stop() throws Exception {
            rmiRegistry.unbind("server"+id);
            unexportObject(this, true);
            unexportObject(rmiRegistry, true);
            System.out.println("Server stopped");
        }

        public void hearGossip(byte arr[])  {
            String msg="";
			try {
				msg = ResultProto.Gossip.parseFrom(arr).getMsg();
			} catch (InvalidProtocolBufferException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
            
        	try {
				Thread.sleep(5000);	
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
           String a[]=msg.split(":");
           int id=Integer.parseInt(a[0]);
           int clk=Integer.parseInt(a[2]);
           if(hash[id]<clk){
        	   System.out.println("Accept: "+msg);
        	   hash[id]=clk;
        	   try {
        		   GossipAssign.processGossip(msg);
        	   } catch (Exception e) {
        		   System.out.print(e);

        	   }
           }
           else
        	   System.out.println("Reject: "+msg);
        	   

    }

  
}
}

public class GossipAssign {

    
    static int n;
    static int idy;
    public static void main(String[] args) throws Exception {
         Server1.ServerImpl server = new Server1.ServerImpl();
       
        
         Scanner s=new Scanner(System.in);
         //System.out.println("Enter number of processess");
         //n=s.nextInt();
           n=Integer.parseInt(args[0]);      
         //System.out.println("Enter server id");
         //idy=s.nextInt();
         idy=Integer.parseInt(args[1]);
         //s.nextLine();
         server.id=idy;
          server.start();
       //  System.out.println("Enter filename");
          String filename;
         if(args.length>2)
        	  filename=args[2];
         else
         while(true)
             ;
         BufferedReader br = new BufferedReader(new FileReader(filename));
         String msg=br.readLine();
                 Thread.sleep( 3000);
                 int i=0;
         while(msg!=null){
        	 
            processGossip(idy+":"+msg+":"+i);
            i++;
            msg=br.readLine();
         }
        
         
    }
    public static void processGossip(String msg) throws NotBoundException, RemoteException, MalformedURLException, InterruptedException
    {
    final String m=msg;
  final  ResultProto.Gossip.Builder gossip = ResultProto.Gossip.newBuilder();
    gossip.setMsg(m);
    
        Random r=new Random();
        int a=r.nextInt(n)+1;
        while(a==idy)
         a=r.nextInt(n)+1;
        
        int b=a;
        while(b==a||b==idy)
            b=r.nextInt(n)+1;
        final int a1=a;
        final int b1=b;
        
   final String url1 = "server"+a;
     final    String url2 = "server"+b;
         new Thread()
         {
             public void run() {
            	 try{
            	 Server1.Server server1 = (Server1.Server)Naming.lookup(url1);
             
                   server1.hearGossip(gossip.build().toByteArray());
            	 }
            	 catch(Exception e){}
             }
         }.start();
         Thread.sleep(2000);
         new Thread()
         {
             public void run() {
            	 try{
            	 Server1.Server server1 = (Server1.Server)Naming.lookup(url2);
                 
                   server1.hearGossip(gossip.build().toByteArray());
            	 }
            	 catch(Exception e){System.out.println(e);}
             }
         }.start();
    }
}
