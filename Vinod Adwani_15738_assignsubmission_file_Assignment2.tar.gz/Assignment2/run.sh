javac GossipAssign.java
rmiregistry &


for (( i = 1; i <= $4; i++ )); do
	if [[ i -le $2 ]]; then

		cd[$i]="java GossipAssign $4 $i $6"
		titles[$i]="$i"	
	else
		cd[$i]="java GossipAssign $4 $i"
		titles[$i]="$i"
	fi
done
tab=" --tab-with-profile=Default"
o=()
for (( i = 1; i <= $4; i++ )); do
  o+=($tab --title="${titles[i]}"  -e "bash -c \"${cd[i]} ; bash\"" )
done

gnome-terminal "${o[@]}"
